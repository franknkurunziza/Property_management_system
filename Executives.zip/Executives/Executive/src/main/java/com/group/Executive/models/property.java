package com.group.Executive.models;

public class property {
}
